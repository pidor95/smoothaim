package com.example.smoothaim;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class SmoothAim implements ClientModInitializer {
    static double RANGE = 4.5;
    static double FOV = 50.0;
    static double SPEED = 6.0;
    static double MAX_STEP = 12;

    static double TRIGGER_DELAY = 80; // мс реакции
    static double TRIGGER_CHARGE = 0.9; // заряд атаки 0..1
    static boolean trigger = false;
    static long seenAt = 0;
    static long fireDelay = 0;

    static boolean enabled = true;
    static KeyBinding toggle;
    static KeyBinding openGui;
    static long last = System.nanoTime();

    @Override
    public void onInitializeClient() {
        toggle = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.smoothaim.toggle", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_R, "category.smoothaim"));
        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.smoothaim.gui", InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT, "category.smoothaim"));

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (toggle.wasPressed()) enabled = !enabled;
            while (openGui.wasPressed()) {
                if (c.currentScreen == null) c.setScreen(new SettingsScreen());
            }
            onTick(c);
        });

        HudRenderCallback.EVENT.register((ctx, tickCounter) -> onFrame());
    }

    static void onTick(MinecraftClient mc) {
        var p = mc.player;
        if (!trigger || p == null || mc.world == null || mc.currentScreen != null
                || mc.interactionManager == null) {
            seenAt = 0;
            return;
        }
        HitResult hit = mc.crosshairTarget;
        if (hit == null || hit.getType() != HitResult.Type.ENTITY
                || !(((EntityHitResult) hit).getEntity() instanceof PlayerEntity t)
                || !t.isAlive() || t.isSpectator()) {
            seenAt = 0;
            return;
        }
        long now = System.currentTimeMillis();
        if (seenAt == 0) {
            seenAt = now;
            fireDelay = (long) (TRIGGER_DELAY + Math.random() * 40);
        }
        if (now - seenAt < fireDelay) return;
        if (p.getAttackCooldownProgress(0.5f) < TRIGGER_CHARGE) return;

        mc.interactionManager.attackEntity(p, t);
        p.swingHand(Hand.MAIN_HAND);
        seenAt = 0;
    }

    static void onFrame() {
        long now = System.nanoTime();
        double dt = Math.min((now - last) / 1e9, 0.05);
        last = now;

        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (!enabled || p == null || mc.world == null || mc.currentScreen != null) return;
        if (!mc.options.attackKey.isPressed()) return;

        Vec3d eye = p.getEyePos();
        double bestDiff = FOV;
        float tYaw = 0, tPitch = 0;
        boolean found = false;

        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;
            if (p.distanceTo(e) > RANGE) continue;

            Vec3d d = e.getBoundingBox().getCenter().subtract(eye);
            float yaw = (float) (Math.toDegrees(Math.atan2(d.z, d.x)) - 90.0);
            float pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.hypot(d.x, d.z)));

            double dy = MathHelper.wrapDegrees(yaw - p.getYaw());
            double dp = pitch - p.getPitch();
            double diff = Math.hypot(dy, dp);

            if (diff < bestDiff) {
                bestDiff = diff;
                tYaw = yaw;
                tPitch = pitch;
                found = true;
            }
        }
        if (!found) return;

        double k = 1.0 - Math.exp(-SPEED * dt);
        double dy = MathHelper.wrapDegrees(tYaw - p.getYaw()) * k;
        double dp = (tPitch - p.getPitch()) * k;
        dy = MathHelper.clamp(dy, -MAX_STEP, MAX_STEP);
        dp = MathHelper.clamp(dp, -MAX_STEP, MAX_STEP);

        p.setYaw((float) (p.getYaw() + dy));
        p.setPitch(MathHelper.clamp((float) (p.getPitch() + dp), -90f, 90f));
    }
}
