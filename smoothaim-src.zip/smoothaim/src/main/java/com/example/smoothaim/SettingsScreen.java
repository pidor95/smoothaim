package com.example.smoothaim;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;
import java.util.function.DoubleSupplier;

public class SettingsScreen extends Screen {
    public SettingsScreen() {
        super(Text.literal("SmoothAim"));
    }

    @Override
    protected void init() {
        int w = 200, h = 20, x = width / 2 - w / 2, y = height / 2 - 70;

        addDrawableChild(ButtonWidget.builder(label(), b -> {
            SmoothAim.enabled = !SmoothAim.enabled;
            b.setMessage(label());
        }).dimensions(x, y, w, h).build());

        addDrawableChild(new Setting("Speed", 1, 20, 0.5, w, x, y + 26,
                () -> SmoothAim.SPEED, v -> SmoothAim.SPEED = v));
        addDrawableChild(new Setting("FOV", 5, 180, 1, w, x, y + 52,
                () -> SmoothAim.FOV, v -> SmoothAim.FOV = v));
        addDrawableChild(new Setting("Range", 1, 6, 0.1, w, x, y + 78,
                () -> SmoothAim.RANGE, v -> SmoothAim.RANGE = v));
        addDrawableChild(new Setting("Max step", 1, 45, 1, w, x, y + 104,
                () -> SmoothAim.MAX_STEP, v -> SmoothAim.MAX_STEP = v));

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, y + 134, w, h).build());
    }

    private Text label() {
        return Text.literal("Aim assist: " + (SmoothAim.enabled ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 95, 0xFFFFFF);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class Setting extends SliderWidget {
        final String name;
        final double min, max, step;
        final Consumer<Double> setter;

        Setting(String name, double min, double max, double step, int w, int x, int y,
                DoubleSupplier getter, Consumer<Double> setter) {
            super(x, y, w, 20, Text.empty(), (getter.getAsDouble() - min) / (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.step = step;
            this.setter = setter;
            updateMessage();
        }

        double real() {
            double v = min + value * (max - min);
            return MathHelper.clamp(Math.round(v / step) * step, min, max);
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(name + ": " + String.format("%.1f", real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
        }
    }
}
