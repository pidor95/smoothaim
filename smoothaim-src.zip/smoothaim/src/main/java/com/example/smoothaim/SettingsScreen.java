package com.example.smoothaim;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.function.Consumer;
import java.util.function.DoubleSupplier;

public class SettingsScreen extends Screen {
    static int tab = 0; // 0 = Aim Assist, 1 = Triggerbot

    public SettingsScreen() {
        super(Text.literal("SmoothAim"));
    }

    @Override
    protected void init() {
        int w = 200, x = width / 2 - w / 2, top = 6;

        addDrawableChild(ButtonWidget.builder(
                Text.literal(tab == 0 ? "[Aim Assist]" : "Aim Assist"),
                b -> { tab = 0; clearAndInit(); }).dimensions(x, top, 76, 20).build());
        addDrawableChild(ButtonWidget.builder(
                Text.literal(tab == 1 ? "[Triggerbot]" : "Triggerbot"),
                b -> { tab = 1; clearAndInit(); }).dimensions(x + 80, top, 76, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("X"), b -> close())
                .dimensions(x + 160, top, 40, 20).build());

        int y = 32, step = 24;
        if (tab == 0) {
            addDrawableChild(ButtonWidget.builder(onOff("Aim assist", SmoothAim.enabled), b -> {
                SmoothAim.enabled = !SmoothAim.enabled;
                b.setMessage(onOff("Aim assist", SmoothAim.enabled));
            }).dimensions(x, y, w, 20).build());
            addDrawableChild(new Setting("Speed", 1, 20, 0.5, w, x, y + step,
                    () -> SmoothAim.SPEED, v -> SmoothAim.SPEED = v));
            addDrawableChild(new Setting("FOV", 5, 180, 1, w, x, y + step * 2,
                    () -> SmoothAim.FOV, v -> SmoothAim.FOV = v));
            addDrawableChild(new Setting("Range", 1, 6, 0.1, w, x, y + step * 3,
                    () -> SmoothAim.RANGE, v -> SmoothAim.RANGE = v));
            addDrawableChild(new Setting("Max step", 1, 45, 1, w, x, y + step * 4,
                    () -> SmoothAim.MAX_STEP, v -> SmoothAim.MAX_STEP = v));
        } else {
            addDrawableChild(ButtonWidget.builder(onOff("Triggerbot", SmoothAim.trigger), b -> {
                SmoothAim.trigger = !SmoothAim.trigger;
                b.setMessage(onOff("Triggerbot", SmoothAim.trigger));
            }).dimensions(x, y, w, 20).build());
            addDrawableChild(new Setting("Delay ms", 0, 300, 5, w, x, y + step,
                    () -> SmoothAim.TRIGGER_DELAY, v -> SmoothAim.TRIGGER_DELAY = v));
            addDrawableChild(new Setting("Charge", 0.5, 1.0, 0.05, w, x, y + step * 2,
                    () -> SmoothAim.TRIGGER_CHARGE, v -> SmoothAim.TRIGGER_CHARGE = v));
        }
    }

    private static Text onOff(String name, boolean on) {
        return Text.literal(name + ": " + (on ? "ON" : "OFF"));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            close();
            return true;
        }
        return super.keyPressed(key, scan, mods);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static class Setting extends SliderWidget {
        final String name;
        final double min, max, step;
        final Consumer<Double> setter;

        Setting(String name, double min, double max, double step, int w, int x, int y,
                DoubleSupplier getter, Consumer<Double> setter) {
            super(x, y, w, 20, Text.empty(), (getter.getAsDouble() - min) / (max - min));
            this.name = name;
            this.min = min;
            this.max = max;
            this.step = step;
            this.setter = setter;
            updateMessage();
        }

        double real() {
            double v = min + value * (max - min);
            return MathHelper.clamp(Math.round(v / step) * step, min, max);
        }

        @Override
        protected void updateMessage() {
            setMessage(Text.literal(name + ": " + String.format("%.2f", real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
        }
    }
}
